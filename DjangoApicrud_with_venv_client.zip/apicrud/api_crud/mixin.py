


from django.core.serializers import serialize
import json 
from django.http import HttpResponse 

class SerializeMixin(object):#obj class due to mix in not extends any class
	"""docstring for SerializeMixin"""
	def serialize1(self,qs):

		json_dta = serialize('json',qs)#returns json data
		p_data = json.loads(json_dta) #convert json to dic to remoce information

		final_list = []
		for obj in p_data:
				emp_data = obj['fields']
				final_list.append(emp_data)

		json_dta = json.dumps(final_list)
		return json_dta 


class HttpResponseMixin(object):#obj class due to mix in not extends any class
	"""docstring for SerializeMixin"""
	def render_httpResponse(self,json_data,status=200):
		return HttpResponse(json_data,content_type='application/json',status=status)
