from django.shortcuts import render

# Create your views here.


from django.http import HttpResponse
from django.views.generic import View 
from api_crud.models  import Employee
import json
from api_crud.mixin import SerializeMixin  #to serilize dat 
from api_crud.mixin import HttpResponseMixin #to return json response easy way 
from api_crud.util import is_json #to return json response easy way 
from api_crud.form import EmployeeForm #to return json response easy way 

class EmployeeCRUD_CBV(SerializeMixin,HttpResponseMixin ,View):
	"""docstring for EmployeeCRUD_CBV"""
	def get_object_by_id(self,id): #just check object found or not
		try:
			emp = Employee.objects.get(id=id)
		except Employee.DoesNotExist:
			emp = None
		return emp

	def get(self,request,*args,**kwargs):

		data = request.body
		is_valid_json  = is_json(data)
		#first check is returnng data is json or nor
		if not is_valid_json : 
			json_data = json.dumps({'msg': 'Please provide valid  json data for get by id method  '})
			print('5'*50)
			return self.render_httpResponse(json_data)

		print('*'*50)

		#check if there is any id in json 
		pdata  = json.loads(data)
		id_emp  = pdata.get('id',None) #id have return it other wise none

		if id_emp is not None:
			emp  = self.get_object_by_id(id_emp)

			if emp is None:
				json_data = json.dumps({'msg': 'request emp not found '})
				print('5'*50)
				return self.render_httpResponse(json_data)
			#if found single emp 
			json_data = self.serialize1([emp,])
			return self.render_httpResponse(json_data)

		#id ther is no id then it will return all employee data 
		try :
			qs = Employee.objects.all()
		except Employee.DoesNotExist:
			json_data = josn.dumps({'msg':'sorry no emp found empty '})
			# return HttpResponse(json_data)
			return self.render_httpResponse(json_data)
		else:
			json_data = self.serialize1(qs) #if query set work fine then get json cleaned data from mixin class
			# return HttpResponse(json_data)
			return self.render_httpResponse(json_data)





# ___________________post______________________________


	def post(self,request,*args,**kwargs):

		data = request.body
		is_valid_json = is_json(data)
		if not is_valid_json:#return if json is not valid 
			json_data = json.dumps({'msg':'sorry no jsondata  '})
			return self.render_httpResponse(json_data)

		emp_submited_data = json.loads(data)#convert json to dictionary
		form = EmployeeForm(emp_submited_data)
		if form.is_valid():
			form.save(commit=True)
			json_data = json.dumps({'msg':'Resource created success fylly  '})
			return self.render_httpResponse(json_data)
		if form.errors:
			json_data = json.dumps(form.errors)
			return self.render_httpResponse(json_data)


# ______________________put__________________





	def put(self,request,*args,**kwargs):

		data = request.body
		is_valid_json_data = is_json(data)

		if not is_valid_json_data:
			json_data = json.dumps({'msg': 'Please provide valid  json data for get by id method  '})
			return self.render_httpResponse(json_data)

		p_dta = json.loads(data)
		emp_id = p_dta.get('id',None) 

		if emp_id is None:
			json_data = json.dumps({'msg': 'Please provide id to update id  '})
			return self.render_httpResponse(json_data)

		emp = self.get_object_by_id(emp_id)
		if emp is None:
			json_data = json.dumps({'msg': 'Requested employee not found '})
			return self.render_httpResponse(json_data)

		provided_data_to_update  = json.loads(data)
		orignal_data = {
			'eno' : emp.eno,
			'enam' : emp.enam,
			'esal' : emp.esal,
			'eddr' : emp.eddr, 
		}

		orignal_data.update(provided_data_to_update)
		form = EmployeeForm(orignal_data,instance= emp) #validate data 
		if form.is_valid():
			form.save(commit=True)
			json_data = json.dumps({'msg': 'Employee updated succesfully  '})
			return self.render_httpResponse(json_data)
		if form.errors:
			json_data = json.dumps(form.errors)
			return self.render_httpResponse(json_data)
	




# ______________________delete__________________



	def delete(self,request,*args,**kwargs):

		data = request.body
		is_valid_json_data = is_json(data)

		if not is_valid_json_data:
			json_data = json.dumps({'msg': 'Please provide valid  json data for get by id method  '})
			return self.render_httpResponse(json_data)

		p_dta = json.loads(data)
		emp_id = p_dta.get('id',None) 

		if emp_id is None:
			json_data = json.dumps({'msg': 'Please provide id to Delete id  '})
			return self.render_httpResponse(json_data)

		emp = self.get_object_by_id(emp_id)
		if emp is None:
			json_data = json.dumps({'msg': 'Requested employee not found '})
			return self.render_httpResponse(json_data)
		

		status,delete_item= emp.delete()
		if status == 1 :
			json_data = json.dumps({'msg': 'Requested employee deleted succesfully '})
			return self.render_httpResponse(json_data)

		json_data = json.dumps({'msg': 'Sorry Requested employee not delete try again  '})
		return self.render_httpResponse(json_data)


