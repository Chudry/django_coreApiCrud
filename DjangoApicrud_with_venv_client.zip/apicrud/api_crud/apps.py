from django.apps import AppConfig


class ApiCrudConfig(AppConfig):
    name = 'api_crud'
