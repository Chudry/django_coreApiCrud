















from django.urls import path,include
from api_crud import views


urlpatterns = [

    path('api/',views.EmployeeCRUD_CBV.as_view()),
    # path('api/',views.EmployeeCRUD_CBV.as_view()),
]
