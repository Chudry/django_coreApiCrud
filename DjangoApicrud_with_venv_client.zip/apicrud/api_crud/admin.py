from django.contrib import admin

# Register your models here.
from .models import Employee



class EmployeeAdmin(admin.ModelAdmin):
	"""docstring for EmployeeAdmin"""

	list_display = ['id','eno','enam','esal','eddr']



admin.site.register(Employee,EmployeeAdmin)
