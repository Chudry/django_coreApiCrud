# # import requests
# # base_url = 'http://127.0.0.1:8000/'
# # # endpipnt = 'json_responseFunction'
# # endpipnt = 'json_CBVFunction/'

# # # r = requests.get(base_url+endpipnt)
# # r = requests.post(base_url+endpipnt)
# # data = r.json()  #data is json object 
# # print(r.text)
# # # print('*'*30)
# # print(data)
# # # print('emp eno ',data['eno'])
# # # print('emp ename',data['ename'])
# # # print('emp esal',data['esal'])
# # # print('emp addr',data['eaddr'])

# # # print('*'*30)

 
# # ____________________________________________ post
# import requests
# # import json 
# # base_url = 'http://127.0.0.1:8000/'
# # endpipnt = 'apiDynamic/'

# # def get_resource(id):

# # 	re = base_url+endpipnt+str(id)+'/'
# # 	# resp = requests.get(base_url+endpipnt+id+'/')
# # 	resp = requests.get(re)
# # 	print(resp.status_code)
# # 	print(resp.json())

# # # get_resource(1)
# # # _________________________________________put

# # list of all emp 
# import json
# # base_url = 'http://127.0.0.1:8000/'
# # endpipnt = 'apiDynamicList/'

# # def get_all_emp():

# # 	re = base_url+endpipnt
# # 	resp = requests.get(re)
# # 	r = resp.status_code
# # 	if r in range(200,300):#or request.codes.ok
# # 		print(resp.status_code)
# # 		print(resp.json())
# # 	else : 
# # 		print('sorry api does not work	\nstatus code :', r)	

# # get_all_emp()


# # ++++++++++++++++++++++++++++++++++++++

# base_url = 'http://127.0.0.1:8000/'
# endpipnt = 'apiDynamicList/'

# def crete_resource():
# 	new_amp={
# 		  "eno": 15,
#           "enam": "from post",
#           "esal": 2333333.0,
#           "eddr": "post data "
# 	}

# 	json_data = json.dumps(new_amp) 
# 	resp = requests.post(base_url+endpipnt,data=json_data)
# 	print(resp.status_code)
# 	print(resp.json())

# # crete_resource()


# # _______________________________________________________________

# # put method

# base_url = 'http://127.0.0.1:8000/'
# endpipnt = 'apiDynamic/'

# def update_resource(id):
# 	new_amp={

#           "esal": 100000,
#           "eddr": "karachi"
# 	}

# 	json_data = json.dumps(new_amp) 
# 	resp = requests.put(base_url+endpipnt+str(id)+'/',data=json_data)
# 	print(resp.status_code)
# 	print(resp.json())

# # update_resource(8)

# # _________________________________________________________
# # delete

# base_url = 'http://127.0.0.1:8000/'
# endpipnt = 'apiDynamic/'

# def delete_resource(id):

# 	resp = requests.delete(base_url+endpipnt+str(id)+'/')
# 	print(resp.status_code)	
# 	print(resp.json())


# # delete_resource(8)
























































# # _________________________________________crud operation
import requests
import json

base_url= 'http://127.0.0.1:8000/'
end_piont='api/'

def get_Resource(id = None):

	data = {}
	if id is not None:
		data = {

			'id' : id
		}

	resp = requests.get(base_url+end_piont,data=json.dumps(data))
	print(resp.status_code)	
	print(resp.json())

# get_Resource(3)


def create_resource():

	new_amp={
		  "eno": 15,
          "enam": "from post",
          "esal": 23.0,
          "eddr": "post data",
	}

	json_data = json.dumps(new_amp) 
	resp = requests.post(base_url+end_piont,data=json_data)
	print(resp.status_code)
	print(resp.json())

# create_resource()



def update_resource(id):

	new_amp={
		  'id' : id,
          "esal": 230000.0,
          "eddr": "peshawar",
	}

	json_data = json.dumps(new_amp) 
	resp = requests.put(base_url+end_piont,data=json_data)
	print(resp.status_code)
	print(resp.json())

# update_resource(6)



def delete_resource(id):

	new_amp={
		  'id' : id,

	}

	json_data = json.dumps(new_amp) 
	resp = requests.delete(base_url+end_piont,data=json_data)
	print(resp.status_code)
	print(resp.json())

delete_resource(6)